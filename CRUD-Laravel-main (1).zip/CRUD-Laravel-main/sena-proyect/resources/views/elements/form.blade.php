Formulario que tendra datos en comun con create.
